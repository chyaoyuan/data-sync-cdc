import aiohttp
from aiohttp import ClientSession
from pydantic import BaseModel
from .model import PutSourceModel, GetSourceModel
from loguru import logger


class Settings(BaseModel):
    EntityStorageServerHost: str


class SourceEntityStorageApp:
    def __init__(self, session: ClientSession, settings: dict):
        self.session: ClientSession = session
        self.settings = Settings(**settings)

    async def put_entity(self, data: dict):
        data = PutSourceModel(**data)
        res = await self.session.put(
            f"{self.settings.EntityStorageServerHost}/v6/entity/{data.tenant}/{data.source_entity_type}/{data.source_id}",
            ssl=False,
            json=data.payload,)
        logger.info(res.status)
        if res.status == 200:
            logger.info(f"Json原件存储成功 {data.tenant}={data.source_entity_type}={data.source_id}")
            return True
        else:
            logger.info(f"Json原件存储成失败 {data.tenant}={data.source_entity_type}={data.source_id}")
            return False

    async def get_entity(self, data: dict):
        data = GetSourceModel(**data)
        res = await self.session.get(
            f"{self.settings.EntityStorageServerHost}/v6/entity/{data.tenant}/{data.source_entity_type}/{data.source_id}",
            ssl=False)
        if res.status == 200:
            info = await res.json()
        else:
            info = await res.text()
        if res.status == 404:
            logger.info(f"Json原件不存在 {data.tenant}={data.source_entity_type}={data.source_id}")
            info = {}
        elif res.status == 200:
            logger.info(f"Json原件获取成功 {data.tenant}={data.source_entity_type}={data.source_id}")
            return info, res.status
        else:
            raise Exception(f"Json原件获取失败 {data.tenant}={data.source_entity_type}={data.source_id}={info}={res.status}")
        return info, res.status
