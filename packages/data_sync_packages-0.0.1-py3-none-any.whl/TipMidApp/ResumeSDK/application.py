from typing import Optional

from aiohttp import ClientSession
from loguru import logger
from pydantic import BaseModel, Field


class Settings(BaseModel):
    ResumeSDKServerHost: str
    Authorization:Optional[str] = Field(default="085c11ede59c44588116918f0d3ee1ed")


class ResumeSDKApplication:
    def __init__(self, session: ClientSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)
        self.headers = {
            'Authorization': 'APPCODE ' + self.settings.Authorization,
            'Content-Type': 'application/json; charset=UTF-8',
        }

    async def parse(self, file_name: str, file_content: str):

        data = {
            "file_name": file_name,
            "file_cont": file_content,
            "need_avatar": 1,
            "ocr_type": 1,
            "need_social_exp": 1,
        }
        res = await self.session.post("http://resumesdk.market.alicloudapi.com/ResumeParser", ssl=False, json=data, headers=self.headers)
        if res.status == 200:
            response_info = await res.json()
            return response_info.get("result", {})
        logger.error(res.status)
        logger.error(await res.text())