import asyncio

from aiohttp import ClientSession
from loguru import logger
from pydantic import BaseModel


class Settings(BaseModel):
    ConvertServerHost: str


class ConvertApp:
    def __init__(self, session: ClientSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)
        self.semaphore = asyncio.Semaphore(24)

    async def convert(self, task_id: str, data: dict):
        data = {"task_ids": [task_id], "data": [data]}
        res = await self.session.post(f"{self.settings.ConvertServerHost}/v2/converter", json=data,ssl=False)
        if res.status == 200:
            info = await res.json()
            return info["data"][0], res.status
        info = await res.text()
        return info, res.status

    async def convert_batch(self, task_id: str, data_list: list):
        data = {"task_ids": [task_id for i in range(0, len(data_list))], "data": data_list}
        res = await self.session.post(f"{self.settings.ConvertServerHost}/v2/converter", ssl=False, json=data)
        if res.status == 200:
            info = await res.json()
            info = info["data"]
            return info, res.status
        info = await res.text()
        return info, res.status

    async def convert_tuple(self, task_id: str, data: dict) -> tuple:
        """为了数据能对上把原数据也一并返回"""
        while True:
            try:
                async with self.semaphore:
                    _data = {"task_ids": [task_id], "data": [data["entity"]["rawData"]["content"]]}
                    res = await self.session.post(f"{self.settings.ConvertServerHost}/v2/converter", json=_data, ssl=False,timeout=9999999)
                    if res.status == 200:
                        info = await res.json()
                        return info["data"][0], data
                    info = await res.text()
                    return info, data
            except Exception as e:
                logger.error(e)
                await asyncio.sleep(3)

    async def convert_batch_tuple(self, task_id: str, data_list: list) -> tuple:
        """为了数据能对上把原数据也一并返回"""
        while True:
            try:
                async with self.semaphore:
                    _data_list = {"task_ids": [task_id for i in range(0, len(data_list))], "data": data_list}
                    res = await self.session.post(f"{self.settings.ConvertServerHost}/v2/converter", json=_data_list, ssl=False, timeout=9999999)
                    if res.status == 200:
                        info = await res.json()
                        return info["data"], _data_list
                    info = await res.text()
                    return info, data_list
            except Exception as e:
                logger.error(e)
                await asyncio.sleep(1)

