from typing import Optional

from aiohttp import ClientSession
from pydantic import BaseModel, Field


class Settings(BaseModel):
    TipJobParseServerHost: str
    Authorization: Optional[str] = Field(default="085c11ede59c44588116918f0d3ee1ed")


class ParseBody(BaseModel):
    description: str


class TipJobParseV2:
    def __init__(self, session: ClientSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)

    async def parse(self, body: dict):
        res = await self.session.post(url=self.settings.TipJobParseServerHost,
                                      json=ParseBody(**body), ssl=False)
        status = res.status
        if status == 200:
            info = await res.json()
        else:
            info = await res.text()
        return info, status
