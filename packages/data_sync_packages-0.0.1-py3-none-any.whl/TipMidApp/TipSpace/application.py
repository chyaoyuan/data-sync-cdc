import aiohttp
from aiohttp import ClientSession
from pydantic import BaseModel


class Settings(BaseModel):
    TipSpaceServerHost: str


class TipSpaceApp:
    def __init__(self, session: ClientSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)

    async def create_space_trees(self, task_id: str, data: dict):
        data = {"task_ids": task_id, "data": [data]}
        res = await self.session.post(f"{self.settings.TipSpaceServerHost}/v2/converter", json=data)
        if res.status == 200:
            info = await res.json()
            return info["data"][0], res.status
        info = await res.text()
        return info, res.status


