
from aiohttp import ClientSession
from pydantic import BaseModel


class Settings(BaseModel):
    TipTransmitterServerHost: str


class TransmitterApp:
    def __init__(self, session: ClientSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)

    async def put(self, tenant: str, entity_type: str, open_id: str, source: str, editor: str, data: dict,):
        url = f"{self.settings.TipTransmitterServerHost}/v3/entity/{tenant}/{entity_type}/{open_id}"
        headers = {
            "X-Source": source,
            "X-Editor": editor,
        }

        res = await self.session.post(url, json=data, ssl=False, headers=headers)
        if res.status == 200:
            info = await res.json()
            return info, res.status
        info = await res.text()
        return info, res.status

    async def patch(self, tenant: str, entity_type: str, open_id: str, source: str, editor: str, data: list,):
        url = f"{self.settings.TipTransmitterServerHost}/v3/entity/{tenant}/{entity_type}/{open_id}"
        headers = {
            "Content-Type": "application/json-patch+json",
            "X-Source": source,
            "X-Editor": editor,
        }
        res = await self.session.post(url, json=data, ssl=False, headers=headers)
        if res.status == 200:
            info = await res.json()
            return info, res.status
        info = await res.text()
        return info, res.status

    async def merge(self, tenant: str, entity_type: str, open_id: str, source: str, editor: str, data: dict,):
        url = f"{self.settings.TipTransmitterServerHost}/v3/entity/{tenant}/{entity_type}/{open_id}"
        headers = {
            "Content-Type": "application/merge-patch+json",
            "X-Source": source,
            "X-Editor": editor,
        }
        res = await self.session.post(url, json=data, ssl=False, headers=headers)
        if res.status == 200:
            info = await res.json()
            return info, res.status
        info = await res.text()
        return info, res.status



