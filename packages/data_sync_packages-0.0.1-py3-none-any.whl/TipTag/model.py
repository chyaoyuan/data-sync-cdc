from typing import List

from pydantic import BaseModel


class ExtractBodyModel(BaseModel):
    texts: List[str]
    field: str
    domain: str
    output_category: str
    top_k: int
