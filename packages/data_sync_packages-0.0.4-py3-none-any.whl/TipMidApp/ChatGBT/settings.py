import json
import os
import openai
import csv

from loguru import logger


class OpenAISettings:
    USE_OPENAI_FROM = os.environ.get("USE_OPENAI_FROM", "azure")
    OPENAI_ALLOW_LIST = ["local", "azure"]
    if USE_OPENAI_FROM not in OPENAI_ALLOW_LIST:
        raise Exception(f"only allow->{OPENAI_ALLOW_LIST} not {USE_OPENAI_FROM}")

    TIMEOUT_MS: int = 100000
    EMBEDDING_CHAPTER_MAX_TOKEN: int = 500
    EMBEDDING_DOC_MAX_TOKEN: int = 8191
    COMPLETION_MAX_TOKENS: int = 1000
    GPT_35_MAX_TOKEN: int = 4096

    if USE_OPENAI_FROM == "azure":
        CHAT_MODEL = 'gpt-35-turbo'
        ENCODER_MODEL = "text-embedding-ada-002"
        openai.api_key = "2ce14e2a7e66420db3b76988adea04e9"
        openai.api_type = "azure"
        openai.api_base = "https://tip.openai.azure.com"
        openai.api_version = "2023-03-15-preview"

    else:
        CHAT_MODEL = 'gpt-3.5-turboxxx'
        ENCODER_MODEL = "text-embedding-ada-002xxx"
        ASR_MODEL = 'whisper-1xxx'
        openai.api_key = "sk-MyCdAfjDHrJdDeKJI8nMT3BlbkFJ4l0dv0fQ8k3qVG8gtfZCxxx"

class Settings:
    OpenAISettings = OpenAISettings