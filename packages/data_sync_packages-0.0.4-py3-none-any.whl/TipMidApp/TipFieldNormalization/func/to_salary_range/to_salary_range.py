import re
from typing import Optional
from .model import SalaryRange
from ...utils.salary.salary import norm_fn


_reg_months = re.compile(r'(\d+)[薪星]')
_reg_period = re.compile('(年|月|日|天|小时|时|month|year|hour|day)', re.IGNORECASE)
_reg_unit = re.compile(r'(美金|人民币|元|CNY|dollar|USD|EUR|GBP|JPY|\$|¥)', re.IGNORECASE)
_reg_non_salary = re.compile(r'[^\-~～—\dkw万千十百亿\.]', re.IGNORECASE)
_reg_split = re.compile(r'[\-~～—]')

def adjust_float_to_match_magnitude(a,lt_number, b):
    # 提取a中的浮点数，例如，从"3.6万"中提取出3.6)
    match = re.match(r'([\d.]+)', a)
    if match:
        a_float = float(match.group(1))
        # 计算数量级的差异
        diff = lt_number/a_float*b
        return diff
    else:
        return None

def _get_amount_val(_key: str, gt_amount, lt_amount, gt_number, lt_number, data_types):
    origin_gt_num = gt_amount[_key] if _key in gt_amount and gt_amount[_key] else None
    origin_lt_num = lt_amount[_key] if _key in lt_amount and lt_amount[_key] else None

    if origin_gt_num and list(filter(lambda x: isinstance(origin_gt_num, x), data_types)):
        gt_number = origin_gt_num
    if origin_lt_num and list(filter(lambda x: isinstance(origin_gt_num, x), data_types)):
        lt_number = origin_lt_num
    return gt_number, lt_number


def parse_salary(x: str, data_obj: dict):
    if not x:
        return

    ret_months = _reg_months.findall(x)
    months = int(ret_months[0]) if ret_months else None

    ret_period = _reg_period.findall(x)
    _period = ret_period[0].lower() if ret_period else None
    if _period == '年':
        _period = 'year'
    elif _period == '月':
        _period = 'month'
    elif _period in ['日', '天']:
        _period = 'day'
    elif _period in ['小时', '时']:
        _period = 'hour'

    ret_unit = _reg_unit.findall(x)
    unit = ret_unit[0].upper() if ret_unit else 'CNY'
    if unit in ['元', '人民币', '¥']:
        unit = 'CNY'
    elif unit in ['美金', 'dollar', '$']:
        unit = 'UDS'

    tmp_x = _reg_months.sub('', x)
    tmp_x = _reg_period.sub('', tmp_x)
    tmp_x = _reg_unit.sub('', tmp_x)
    tmp_x = _reg_non_salary.sub('', tmp_x)

    moneys = _reg_split.split(tmp_x)[:2]
    moneys = list(map(lambda a: a.strip(), moneys))
    norm_moneys = list(map(lambda a: norm_fn(a), moneys))
    norm_moneys = list(map(lambda a: a['value'] if 'value' in a else None, norm_moneys))

    gt_number = lt_number = gt_value = lt_value = None
    if len(norm_moneys) > 1:
        gt_value, lt_value = f'{moneys[0]}', f'{moneys[1]}'
        gt_number, lt_number = norm_moneys[0], norm_moneys[1]
    elif moneys:
        gt_value = lt_value = f'{moneys[0]}'
        gt_number = lt_number = norm_moneys[0]

    if not gt_number and not lt_number:
        unit = None

    gt = data_obj['gt'] if 'gt' in data_obj and data_obj['gt'] else {}
    lt = data_obj['lt'] if 'lt' in data_obj and data_obj['lt'] else {}

    gt_amount = gt['amount'] if 'amount' in gt and gt['amount'] else {}
    lt_amount = lt['amount'] if 'amount' in lt and lt['amount'] else {}

    gt_months, lt_months = _get_amount_val('months', gt, lt, months, months, [int])
    gt_period, lt_period = _get_amount_val('period', gt, lt, _period, _period, [str])

    gt_number, lt_number = _get_amount_val('number', gt_amount, lt_amount, gt_number, lt_number, [int, float])
    gt_value, lt_value = _get_amount_val('value', gt_amount, lt_amount, gt_value, lt_value, [str])
    gt_unit, lt_unit = _get_amount_val('unit', gt_amount, lt_amount, unit, unit, [str])
    _ =  {
            'openClose': 'open-close',
            'rangeString': x,
            'gt': {
                'months': gt_months,
                'period': gt_period,
                'amount': {
                    'number': gt_number,
                    'unit': gt_unit,
                    'value': gt_value,
                }
            },
            'lt': {
                'months': lt_months,
                'period': lt_period,
                'amount': {
                    'number': lt_number,
                    'unit': lt_unit,
                    'value': lt_value,
                }
            }
        }

    lt_number = _['lt']['amount']['number']

    if not lt_number:
        return SalaryRange(**_)
    # number_str = str(int(lt_number))
    #
    # # 初始化零的计数器
    # zero_count = 0
    #
    # # 遍历字符串从右往左，计算后面有多少个零
    # for char in reversed(number_str):
    #     if char == '0':
    #         zero_count += 1
    #     else:
    #         break
    # print(f"xxx->{zero_count}")
    # # 增加相同数量的零
    # print(f"xxxxxxx->{gt_number}")
    # result_number = gt_number * (10 ** zero_count)
    result = adjust_float_to_match_magnitude(lt_value,lt_number, gt_number)

    _['gt']['amount']['number'] = result
    return SalaryRange(**_)


def convert(x: str) -> Optional[SalaryRange]:
    obj = SalaryRange(rangeString=x)
    if x:
        return parse_salary(x, obj.dict())


if __name__ == '__main__':
    print(convert("1-1.4万"))
    print(convert('1000-2000元/月'))
#     print(convert('1000~2000元/年'))
#     print(convert('~2000k/月'))
#     # 不太行啊！
#     print(convert('6千-1.2万/月'))
#     print(convert('14万/年'))
#     print(convert('10000元/年'))
#     print(convert('10-15w/年'))
#     print(convert('1、月薪6-10K'))
#     print(convert('1、月薪6K-10K'))
#
#     print(convert('30 - 40k  16薪'))
