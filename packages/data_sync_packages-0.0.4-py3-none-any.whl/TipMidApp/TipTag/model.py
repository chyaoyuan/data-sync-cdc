from typing import List, Optional

from pydantic import BaseModel, Field


class ExtractBodyModel(BaseModel):
    texts: List[str]
    field: Optional[str] = Field(default="description")
    domain: Optional[str] = Field(default="hr")
    output_category: str
    top_k: Optional[int] = Field(default=1)


class ExpandBodyModel(BaseModel):
    texts: List[str]
    field: Optional[str] = Field(default="description")
    domain: Optional[str] = Field(default="hr")
    output_category: str
    top_k: Optional[int] = Field(default=1)
    recall_top_k: Optional[int] = Field(default=10)
    rerank: Optional[bool] = Field(default=False)
    timeout: Optional[int] = Field(default=20)