
from aiohttp import ClientSession
from pydantic import BaseModel
from .model import ExtractBodyModel


class Settings(BaseModel):
    TipTagServerHost: str


class TipTagApp:
    def __init__(self, session: ClientSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)

    async def extract(self, data: dict):
        url = f"{self.settings.TipTagServerHost}/v1alpha1/tagging/extract"
        res = await self.session.post(url, json=ExtractBodyModel(**data).dict(), ssl=False)
        if res.status == 200:
            info = await res.json()
            return info["data"][0], res.status
        info = await res.text()
        return info, res.status




