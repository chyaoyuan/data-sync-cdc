import aiohttp
from aiohttp import ClientSession
from pydantic import BaseModel
from .model import PutSourceModel, GetSourceModel
from loguru import logger


class Settings(BaseModel):
    entityStorageServerHost: str


class SourceEntityStorageApp:
    def __init__(self, session: ClientSession, settings: dict):
        self.session: ClientSession = session
        self.settings = Settings(**settings)

    async def put_entity(self, data: dict):
        data = PutSourceModel(**data)
        res = await self.session.put(
            f"{self.settings.entityStorageServerHost}/v6/entity/{data.tenant}/{data.source_entity_type}/{data.source_id}",
            ssl=False,
            json=data.payload,)
        if res.status == 200:
            logger.info(f"Json原件存储成功 {data.tenant}={data.source_entity_type}={data.source_id}")
            return True
        else:
            logger.info(f"Json原件存储成失败 {data.tenant}={data.source_entity_type}={data.source_id}")
            return False

    async def get_entity(self, data: dict):
        data = GetSourceModel(**data)
        res = await self.session.get(
            f"{self.settings.entityStorageServerHost}/v6/entity/{data.tenant}/{data.source_entity_type}/{data.source_id}",
            ssl=False)
        if status := res.status == 200:
            info = await res.json()
        else:
            info = await res.text()
        if status == 404:
            logger.info(f"Json原件不存在 {data.tenant}={data.source_entity_type}={data.source_id}")
            return False, status
        elif status == 200:
            logger.info(f"Json原件获取成功 {data.tenant}={data.source_entity_type}={data.source_id}")
            return info, status
        else:
            logger.info(f"Json原件存储失败 {data.tenant}={data.source_entity_type}={data.source_id}")
            return info, status
