from typing import Optional, List

from pydantic import BaseModel, Extra, Field
from typing_extensions import Literal

from .settings import Settings


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"] = Field(default="user")
    content: str



class ChatRequestModel(BaseModel):
    engine: Optional[str] = Field(default=Settings.OpenAISettings.CHAT_MODEL)
    model: Optional[str] = Field(default=Settings.OpenAISettings.CHAT_MODEL)
    messages: List[ChatMessage]
    stream: bool = False
    stop: List[str] = None  # up to 4 sequences
    max_tokens: int = 1000

    temperature: float = 0.0
    top_p: int = 1
    n: int = 1
    presence_penalty: float = 0.0
    frequency_penalty: float = 0.0

    class Config:
        extra = Extra.allow
