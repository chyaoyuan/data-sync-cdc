"""
重构地址normalize，去除祖传magic number们
1、祖传字典切词
2、DAG、按覆盖度最高、平均span长度最高排序
3、根据2的keywords、取出每个keyword对应的地点编码
4、3的笛卡尔积、根据国家、城市个数、挑选前三个span中、按国家、省市代码出现最少的情况
"""
import re
from itertools import product
from typing import List, Optional
from pydantic import BaseModel
from ...utils.location.china_city_code_to_name import china_city_code_to_name
from ...utils.location.china_district_code_to_name import china_district_code_to_name
from ...utils.location.china_prov_code_to_name import china_prov_code_to_name
from ...utils.location.country_code_to_name import country_code_to_name
from ...utils.location.location_code_to_keywords import location_code_to_keywords
from .model import Location



location_keyword_to_codes = dict()

# 2022.08.11 https://www.mca.gov.cn/article/sj/xzqh/2021/20211201.html
location_code_mapper = {
    '156610322': '156610305',
    '156654223': '156654203',
    '156513425': '156513402',
    '156532331': '156532302',
    '156450127': '156450181',
    '156350681': '156350604',
    '156350625': '156350605',
    '156350402': '156350404',
    '156350403': '156350404',
    '156350427': '156350405',
    '156610928': '156610981',
    '156431121': '156431181',
    '156520522': '156520581',
    '156410381': '156410307',
    '156410322': '156410308',
    '156410306': '156410308',
    '156330104': '156330102',
    '156330103': '156330105'
}

for code, keywords in location_code_to_keywords.items():
    code = location_code_mapper.get(code, code)
    for keyword in keywords:
        location_keyword_to_codes[keyword.lower()] = location_keyword_to_codes.get(keyword.lower(), list()) + [code]

location_window_size = 16

location_keywords = set()

for keywords in location_code_to_keywords.values():
    location_keywords |= set(keyword.lower() for keyword in keywords)

location_keywords = list(location_keywords)


class Span(BaseModel):
    start: int
    end: int
    text: str
    entity: str

# class Location(BaseModel):
#     code: str = Field(default=..., title='地点编码', min_length=9, max_length=9)
#     country: Optional[str] = Field(default=None, title='国家')
#     province: Optional[str] = Field(default=None, title='省')
#     city: Optional[str] = Field(default=None, title='市')
#     district: Optional[str] = Field(default=None, title='区')


def tag(raw_text: str) -> List[Span]:
    spans = list()
    start = 0
    while start < len(raw_text) - 1:
        for offset in range(min(location_window_size, len(raw_text) - start), 0, -1):
            if raw_text[start:start + offset] in location_keywords:
                spans.append(Span(start=start, end=start + offset, text=raw_text[start:start + offset], entity='loc'))
        start += 1
    return spans


def get_paths(input_text: str, spans: List[Span]):
    dag = {index: [Span(start=index, end=index + 1, text=input_text[index], entity='O')] for index in
           range(len(input_text))}
    for span in spans:
        dag[span.start] = dag.get(span.start, list()) + [span]

    # dfs
    queue = [(0, [])]
    paths = list()
    while queue:
        # if bfs, use queue[0]  queue = queue[1:]
        node, path = queue[-1]
        queue = queue[:-1]
        for span in dag[node]:
            if span.end == len(input_text):
                paths.append(path + [span])
            else:
                queue = queue + [(span.end, path + [span])]
    return paths


def path_sort_key(path: List[Span]):
    """
    1 覆盖度
    2 平均span长度
    :param path:
    :return:
    """
    # cover
    none_o_spans = [span for span in path if span.entity != 'O']
    cover_rate = sum(span.end - span.start for span in none_o_spans) / path[-1].end
    avg_span_length = sum(span.end - span.start for span in none_o_spans) / len(none_o_spans) if none_o_spans else 0.
    sort_key = (- cover_rate, - avg_span_length)
    return sort_key


def get_code_from_path(path: List[Span]) -> Optional[str]:
    """
    1、前3个span中，出现的国家、省市越一致越好
    2、如果不一致，按出现的顺序，取一致且最细致的地址编码
    :param path:
    :return:
    """
    span_codes = [location_keyword_to_codes[span.text] for span in path if span.entity != 'O'][:3]

    if not span_codes:
        return None

    code_seqs = [seq for seq in product(*span_codes)]

    get_seq_sort_key = lambda seq: (set(c[:3] for c in seq), set(c[:5] for c in seq if c[-2:] != 00))

    best = sorted(code_seqs, key=get_seq_sort_key)

    best_code_seqs = best[0]

    def count_suffix_zero(s: str) -> int:
        c = 0
        for i in range(len(s) - 1, -1, -1):
            if s[i] == '0':
                c += 1
            else:
                break
        return c

    # 在前4个span中挑选code，省市一致的序列中最细致的一个
    location_code = best_code_seqs[0]
    for i in range(1, len(best_code_seqs)):
        # 中国: 156000000
        if (
                (location_code[-6:] == '000000' or best_code_seqs[i][-6:] == '000000')
                and
                location_code[:3] == best_code_seqs[i][:3]
        ) or best_code_seqs[i][:5] == location_code[:5]:
            best_suffix_zero = count_suffix_zero(location_code)
            new_suffix_zero = count_suffix_zero(best_code_seqs[i])
            location_code = best_code_seqs[i] if new_suffix_zero < best_suffix_zero else location_code
        else:
            break

    return location_code


# country code | country name | prov code | prov name | city code | city name | dis code | dis name
# name_to_code = {'虹口区': ['156', '', '310', '109'],
#                 '上海市': ['156', '', '310'],
#                 '河北省': ['156', '13'],
#                 '廊坊市': ['156', '13', '01'],
#                 '广阳区': ['156', '13', '10', '03']}
class Node(BaseModel):
    code: str
    name: str
    children: List['Node'] = list()


def get_china_location():
    # 非直辖市
    root = Node(code='156', name='中国')
    for prov_code, prov_name in china_prov_code_to_name.items():
        prov_node = Node(code=prov_code, name=prov_name)
        for city_code, city_name in china_city_code_to_name.items():
            if len(city_code) != 4 or city_code[:2] != prov_code:
                continue
            city_node = Node(code=city_code[-2:], name=city_name)
            for dis_code, dis_name in china_district_code_to_name.items():
                if dis_code[:4] != city_code:
                    continue
                dis_node = Node(code=dis_code[-2:], name=dis_name)
                city_node.children.append(dis_node)
            prov_node.children.append(city_node)
        root.children.append(prov_node)

    # 直辖市
    for city_code, city_name in china_city_code_to_name.items():
        if len(city_code) != 3:
            continue
        prov_node = Node(code=city_code, name=city_name)
        city_node = Node(code='', name=city_name)
        for dis_code, dis_name in china_district_code_to_name.items():
            if dis_code[:3] != city_code:
                continue
            dis_node = Node(code=dis_code[-3:], name=dis_name)
            city_node.children.append(dis_node)
        prov_node.children.append(city_node)
        root.children.append(prov_node)
    return root.dict()


def convert(loc_str: str, max_length: int = 32) -> Optional[Location]:
    """
    地址解析，最高精确到区。
    :param loc_str: address string
    :param max_length:
    :return: List[Location]
    """
    if loc_str.strip() == '':
        return None
    cleaned_str = re.sub(r'[.)(,\s-]', r'', loc_str).lower()
    cleaned_str = cleaned_str[:max_length]
    spans = tag(cleaned_str)
    paths = get_paths(cleaned_str, spans)
    paths = sorted(paths, key=path_sort_key)

    code = get_code_from_path(paths[0])
    if not code:
        return None

    country = country_code_to_name.get(code[:3])
    prov, city = None, china_city_code_to_name.get(code[3:6])  # 直辖市
    if not city:
        prov, city = china_prov_code_to_name.get(code[3:5]), china_city_code_to_name.get(code[3:7])
    else:
        prov = {
            "北京市": "北京",
            "天津市": "天津",
            "上海市": "上海",
            "重庆市": "重庆",
            "台湾": "台湾省",
            "香港特别行政区": "香港特别行政区",
            "澳门特别行政区": "澳门特别行政区"
        }[city]
    district = china_district_code_to_name.get(code[3:])

    # http://www.mca.gov.cn/article/sj/xzqh/2020/20201201.html
    # 港澳台官方无地市区县信息
    if code in ['156710000', '156810000', '156820000']:
        city = None

    return Location(code=code, country=country, province=prov, city=city, district=district)


# if __name__ == '__main__':
#     print(convert('上海市虹口区虹口足球场'))
#     print(convert('广州大学虹口区虹口足球场'))
#     print(convert('我在上海市虹口区虹口足球场'))
#     print(convert('我在南京长江大桥下面的福建路的东边的小卖部进行了一次交易'))
#     print(convert('beijing'))
