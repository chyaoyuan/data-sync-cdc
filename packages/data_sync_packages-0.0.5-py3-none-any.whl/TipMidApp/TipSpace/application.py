import aiohttp
from aiohttp import ClientSession
from loguru import logger
from pydantic import BaseModel
from ..custom_session.custom_aiohttp_session import HoMuraSession

class Settings(BaseModel):
    TipSpaceServerHost: str


class TipSpaceApp:
    def __init__(self, session: HoMuraSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)

    # async def create_space_trees(self, task_id: str, data: dict):
    #     data = {"task_ids": task_id, "data": [data]}
    #     res = await self.session.post(f"{self.settings.TipSpaceServerHost}/v2/converter", json=data)
    #     if res.status == 200:
    #         info = await res.json()
    #         return info["data"][0], res.status
    #     info = await res.text()
    #     return info, res.status

    async def upsert_note(self, entity_type: str, open_id: str, data: list,tenant_id:str):
        headers = {
            "tenant-Id": tenant_id,
            "user-Id": "mesoor-admin"
        }
        logger.info(data)
        res = await self.session.post(f"{self.settings.TipSpaceServerHost}/v2/entities/{entity_type}/{open_id}/remarks/batch",json=data,ssl=False,headers=headers)
        logger.info(await res.text())
        if res.status == 200:
            logger.info(f"note success-> {entity_type} {open_id}")
        else:
            info = await res.text()
            logger.error(f"note error->{res.status} {info} {entity_type} {open_id}")



