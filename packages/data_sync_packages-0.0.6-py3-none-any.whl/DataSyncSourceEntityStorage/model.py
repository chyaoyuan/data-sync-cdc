from pydantic import BaseModel


class PutSourceModel(BaseModel):
    tenant: str
    source_entity_type: str
    source_id: str
    payload: dict


class GetSourceModel(BaseModel):
    tenant: str
    source_entity_type: str
    source_id: str
