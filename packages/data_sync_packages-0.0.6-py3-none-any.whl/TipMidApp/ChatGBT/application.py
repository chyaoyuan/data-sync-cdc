import asyncio

import aiohttp
from aiohttp import ClientSession
from pydantic import BaseModel
from loguru import logger
from backoff import on_exception, constant, expo
from .error import ChatGBTRequestLimit, ChatGBTOtherError
from .model import ChatRequestModel
from .settings import OpenAISettings
from ..custom_session.custom_aiohttp_session import HoMuraSession

class Settings(BaseModel):
    EntityStorageServerHost: str


class ChatGBTApp:
    def __init__(self, session: HoMuraSession):
        self.session: HoMuraSession = session
        self.settings = OpenAISettings

    @on_exception(expo, (ChatGBTRequestLimit, asyncio.exceptions.TimeoutError), max_time=60)
    async def _ask_gbt(self, request: ChatRequestModel):
        headers = {
            'api-key': '95dd23653c7e464dbf7ed2abd9dc8169',
            'Content-Type': 'application/json'
        }
        url = "https://tip2.openai.azure.com/openai/deployments/gpt-35-turbo-2/chat/completions?api-version=2023-03-15-preview"
        res = await self.session.post(url,
                                      headers=headers,
                                      json={"messages": [message.dict() for message in request.messages],"temperature":0},
                                      ssl=False,
                                      )
        res_contact = await res.text()
        if res.status == 429:
            raise ChatGBTRequestLimit(f"ChatGBT并发超过上限->{res.status}->{res_contact}")
        if res.status != 200:
            response = await res.text()
            raise ChatGBTOtherError("ChatGBT出错, status: {}, response: {}".format(res.status, response))
        result = await res.json()
        answer = result['choices'][0]['message']['content']
        return answer

    def parse_key_value_output(self, result: str, input_dict: dict = None) -> dict:
        categories = input_dict.get('categories', None)
        items = {}
        for line in result.split("\n"):
            logger.info(f"[Generation] {line}")

            if line.strip():
                if "：：" in line or "::" in line:
                    key, value = line.replace("：：", "::").split("::")
                    if value.strip() and value.strip() != '""':
                        values = value.strip().replace('｜', '|').split('|')
                        if not categories:
                            items[key.strip()] = values
                        elif key.strip() in categories:
                            items[key.strip()] = values

        return items

    async def extract(self, body: dict):
        message = """
        {text}

        对以上信息从不同维度提取关键词，维度列表如下：
        {categories}

        输出格式：
        	key1:: value1｜value2｜value3
        	key2:: value1｜value2｜value3
        	...

        格式要求：
        	1. key为维度名称，value为关键词列表，词之间用'｜'分割
        	2. 如果某维度没有关键词，返回""
        	3. 每个维度的关键词数量可以少于{top_k}，但不能多于{top_k}
        	4. 每个维度单独输出一行

        输出结果:
        """.format(text=body["text"], categories=body["categories"],top_k=body["top_k"])
        chat_request = ChatRequestModel(**{"messages":[{"content":message}]})
        v = {
            "categories": body["categories"]
        }
        answer = self.parse_key_value_output(await self._ask_gbt(chat_request),v)
        logger.info(answer)
        return answer


