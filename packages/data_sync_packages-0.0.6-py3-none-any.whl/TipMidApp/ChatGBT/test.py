from loguru import logger

# i = extract_tpl.format(text="月薪8到12K",categories="每月薪资",top_k=2)
# print(i)

def parse_key_value_output(result: str, input_dict: dict = None) -> dict:
    categories = input_dict.get('categories', None)
    items = {}
    for line in result.split("\n"):
        logger.info(f"[Generation] {line}")

        if line.strip():
            if "：：" in line:
                key, value = line.replace("：：", "::").split("::")
                if value.strip() and value.strip() != '""':
                    values = value.strip().replace('｜', '|').split('|')
                    if not categories:
                        items[key.strip()] = values
                    elif key.strip() in categories:
                        items[key.strip()] = values

    return items


if __name__ == '__main__':
    b = {
        "text": "月薪8到12K",
        "categories": "每月薪资",
        "top_k": 2
    }

    i = parse_key_value_output("以下是从不同维度提取的关键词列表：\n每月薪资：：8K｜12K",b)
    print(i)