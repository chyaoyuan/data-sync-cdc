import asyncio
import json

import aiohttp

from ..custom_session.custom_aiohttp_session import HoMuraSession
from aiohttp import ClientSession
from loguru import logger
from pydantic import BaseModel


class Settings(BaseModel):
    ConvertServerHost: str


class ConvertApp:
    def __init__(self, session: HoMuraSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)
        self.semaphore = asyncio.Semaphore(24)

    async def convert_one(self, task_id: str, data: dict):
        async with aiohttp.ClientSession() as session:
            data = {"task_ids": [task_id], "data": [data]}

            res = await session.post(f"{self.settings.ConvertServerHost}/v2/converter", json=data, ssl=False)
            if res.status == 200:
                info = await res.json()
                converted = info["data"][0]
                if not converted:
                    logger.error(f"{res.status}=={await res.text()}")
                return info["data"][0], res.status
            info = await res.text()
            return info, res.status

    async def convert_batch(self, task_id: str, data_list: list, tenant_id: str, source_system: str):
        async with aiohttp.ClientSession() as session:
            data = {"task_ids": [task_id for i in range(0, len(data_list))], "data": data_list, "tenantId": tenant_id,
                    "sourceSystem": source_system}
            res = await session.post(f"{self.settings.ConvertServerHost}/v2/converter", ssl=False, json=data)
            status = res.status
            if status == 200:
                info = await res.json()
                info = info["data"]
                return [_['data'] for _ in info], status

            info = await res.text()
            data["task_ids"] = data["task_ids"][0]
            logger.error(f"转换失败->{json.dumps(data,ensure_ascii=False)} ")
            logger.error(f"{status} {info}")
            return [], status

    async def convert_one_and_format(self, task_id: str, data: dict):
        """为了数据能对上把原数据也一并返回"""
        async with self.semaphore:
            _data = {"task_ids": [task_id], "data": [data]}
            res = await self.session.post(f"{self.settings.ConvertServerHost}/v2/converter", json=_data, ssl=False)
            if res.status == 200:
                info = await res.json()
                result = {
                    "rawData": data,
                    "standardFields": info["data"][0]
                }
                return result

            logger.error(f"{await res.text()}")
            raise Exception

    async def convert_batch_and_format(self, task_id: str, raw_data_list: list):
        async with self.semaphore:
            _data = {"task_ids": [task_id for i in range(0, len(raw_data_list))], "data": raw_data_list}
            res = await self.session.post(f"{self.settings.ConvertServerHost}/v2/converter", json=_data, ssl=False)
            if res.status == 200:
                response = await res.json()
                info_list = response.get("data", [])
                result = []
                for _, raw_data in zip(info_list, raw_data_list):
                    converted_std = info_list["data"]
                    _["rawData"] = raw_data
                    result.append(_)
                return result

            logger.error(f"{await res.text()}")
            raise Exception



