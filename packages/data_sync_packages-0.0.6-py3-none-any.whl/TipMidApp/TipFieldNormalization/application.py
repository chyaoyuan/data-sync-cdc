from .func.to_location.to_location import convert as location_convert
from .func.to_salary_range.to_salary_range import convert as salary_range_convert


class FieldNormalizationApp:

    @staticmethod
    def location(string: str):
        return location_convert(string).dict()

    @staticmethod
    def salary_range(string: str):
        return salary_range_convert(string).dict()
