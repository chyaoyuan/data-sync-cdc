from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class Location(BaseModel):
    address: Optional[str] = Field(title="地址", description="地址")
    city: Optional[str] = Field(title="市", description="市")
    code: Optional[str] = Field(title="编码", description="九位地址编码", min_length=9, max_length=9)
    country: Optional[str] = Field(title="国家", description="国家")
    district: Optional[str] = Field(title="区", description="区")
    postalCode: Optional[str] = Field(title="邮编", description="邮编")
    province: Optional[str] = Field(title="省", description="省")
    region: Optional[str] = Field(title="区域", description="区域")