from __future__ import annotations
from datetime import datetime, timezone, timedelta
from typing import Optional, Literal

from pydantic import BaseModel, Field, validator


class Amount(BaseModel):
    number: Optional[float] = Field(title="数值", description="数值")
    unit: Optional[str] = Field(title="单位", description="单位")
    value: Optional[str] = Field(title="原值", description="原值")


class Salary(BaseModel):
    amount: Optional[Amount] = Field(None, description='金额/货币', title='Currency')
    months: Optional[int] = Field(None, description='薪资月数')
    period: Optional[Literal['hour', 'day', 'week', 'month', 'year']] = Field(
        'month', description='薪制（时｜日｜周｜月｜年）'
    )

    @property
    def to_string(self):
        f"{self.amount}/"


class SalaryRange(BaseModel):
    gt: Optional[Salary] = Field(None, description='薪资下限', title='Salary')
    lt: Optional[Salary] = Field(None, description='薪资上限', title='Salary')
    openClose: Optional[Literal["open-open", "open-close", "close-close", "close-open"]] = Field(
        None, description='开闭类型'
    )
    rangeString: Optional[str] = Field(None, description='薪资范围原文')