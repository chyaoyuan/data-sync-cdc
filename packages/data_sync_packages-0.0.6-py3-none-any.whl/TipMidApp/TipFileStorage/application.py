from typing import Optional, Union, Literal

import aiohttp
from aiohttp import ClientSession
from loguru import logger
from pydantic import BaseModel, Field
from ..custom_session.custom_aiohttp_session import HoMuraSession


class Settings(BaseModel):
    StoreDerivationServerHost: str

class SaveFileBody(BaseModel):
    fileContent: bytes = Field(..., description="文件内容 二进制形式")
    fileName: str = Field(..., description="文件名", example="xxx.pdf")
    key: Optional[str] = Field(default=None, description="文件的key", example="xxx")


class SaveB64FileBody(SaveFileBody):
    fileContent: str = Field(..., description="文件内容 base64形式")


class TipFileStorage:
    def __init__(self, session: HoMuraSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)
        self.save_file_url = f"{self.settings.StoreDerivationServerHost}/store/file/save"
        self.save_b64_file_url = self.settings.StoreDerivationServerHost + "/store/file/save/base64"

    async def _save_file(self, body: Union[SaveB64FileBody, SaveFileBody], mode: Literal['b64', 'file']):
        # if mode == "file":
        #     form_data = aiohttp.FormData()
        #     form_data.add_field("file", body.fileContent, filename=body.fileName)
        #     params = {"key": body.key} if body.key else None
        #     response = await self.session.put(
        #         self.save_file_url, data=form_data, ssl=False, timeout=300, params=params
        #     )
        # else:
        #     params = {"key": body.key} if body.key else None
        #     response = await self.session.put(
        #         self.save_b64_file_url, json={
        #             "content": body.fileContent, "fileName": body.fileName
        #         }, ssl=False, timeout=300,  params=params
        #     )
        # status = response.status
        #
        # if status != 200:
        #     response = await response.json()
        #
        #     raise Exception("存储文件 {} 失败, 原因: {}".format(
        #         body.fileName, response.get("message") or "未知原因"
        #     ))
        # response = await response.json()
        # logger.info("存储文件 {} 成功".format(
        #     response["result"]["key"]
        # ))
        # return response["result"]["key"]
        if mode == "file":
            form_data = aiohttp.FormData()
            form_data.add_field("file", body.fileContent, filename=body.fileName)
            params = {"key": body.key} if body.key else None
            await self.session.put(
                self.save_file_url, data=form_data, ssl=False, timeout=300, params=params
            )
        else:
            params = {"key": body.key} if body.key else None
            await self.session.put(
                self.save_b64_file_url, json={
                    "content": body.fileContent, "fileName": body.fileName
                }, ssl=False, timeout=300, params=params
            )

    async def save_file(self, body: dict) -> str:
        body = SaveFileBody(**body)
        return await self._save_file(body, "file")

    async def save_b64_file(self, body: dict) -> str:
        body = SaveB64FileBody(**body)
        return await self._save_file(body, "b64")
