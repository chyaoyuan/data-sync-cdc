from pydantic import BaseModel


class EntityConfig(BaseModel):
    name: str
    openId: str


class SpaceTreeCreate(BaseModel):
    space: EntityConfig
    channel: EntityConfig
    project: EntityConfig
    entityType: str
    openId: str