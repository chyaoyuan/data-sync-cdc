import json
from typing import Optional

from loguru import logger
from aiohttp import ClientSession
from pydantic import BaseModel
from ..custom_session.custom_aiohttp_session import HoMuraSession

class Settings(BaseModel):
    TipTransmitterServerHost: str


class TransmitterApp:
    def __init__(self, session: HoMuraSession, settings: dict):
        self.session = session
        self.settings = Settings(**settings)

    async def put(self, tenant: str, entity_type: str, open_id: str, source: str, editor: str, data: dict,extra_headers:Optional[dict]):
        url = f"{self.settings.TipTransmitterServerHost}/v2/entity/{tenant}/{entity_type}/{open_id}"
        headers = {
            "Content-Type":"application/json",
            "X-Source": source,
            "X-Editor": editor,
        }
        if extra_headers:
            headers = {**headers, **extra_headers}
        headers = {k: v for k, v in headers.items() if v}
        if "X-Editor" not in headers:
            headers['X-Editor'] = editor
        res = await self.session.put(url, json=data, ssl=False, headers=headers)
        if res.status == 200:
            logger.info(f"rule-success tenant->{tenant}->{entity_type}->{open_id}")
            info = await res.json()
            return info, res.status
        info = await res.text()
        logger.error(f"rule-error tenant->{tenant}->{entity_type}->{open_id}->{res.status}->{info} {json.dumps(headers,ensure_ascii=False)} {json.dumps(data,ensure_ascii=False)}")
        return info, res.status

    async def patch(self, tenant: str, entity_type: str, open_id: str, source: str, editor: str, data: list):
        url = f"{self.settings.TipTransmitterServerHost}/v3/entity/{tenant}/{entity_type}/{open_id}"
        headers = {
            "Content-Type": "application/json-patch+json",
            "X-Source": source,
            "X-Editor": editor,
        }

        res = await self.session.post(url, json=data, ssl=False, headers=headers)
        if res.status == 200:
            info = await res.json()
            return info, res.status
        info = await res.text()
        return info, res.status

    async def merge(self, tenant: str, entity_type: str, open_id: str, source: str, editor: str, data: dict):
        url = f"{self.settings.TipTransmitterServerHost}/v3/entity/{tenant}/{entity_type}/{open_id}"
        headers = {
            "Content-Type": "application/merge-patch+json",
            "X-Source": source,
            "X-Editor": editor,
        }

        res = await self.session.post(url, json=data, ssl=False, headers=headers)
        if res.status == 200:
            info = await res.json()
            return info, res.status
        info = await res.text()
        return info, res.status

    async def get(self, tenant: str, entity_type: str, open_id: str):
        url = f"{self.settings.TipTransmitterServerHost}/v2/entity/{tenant}/{entity_type}/{open_id}"
        res = await self.session.get(url, ssl=False)
        if res.status == 200:
            logger.info(f"rule-success get tenant->{tenant}->{entity_type}->{open_id}")
            info = await res.json()
            return info, res.status
        elif res.status == 404:
            logger.info(f"rule-success get not found tenant->{tenant}->{entity_type}->{open_id}")
            return None, res.status
        info = await res.text()
        logger.error(f"rule-error get tenant->{tenant}->{entity_type}->{open_id}->{res.status}->{info}")
        return info, res.status



