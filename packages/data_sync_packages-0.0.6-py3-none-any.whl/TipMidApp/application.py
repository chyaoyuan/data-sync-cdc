import asyncio

import aiohttp
from typing import Optional
from .DataSyncSourceEntityStorage import SourceEntityStorageApp
from .TipConvert import ConvertApp
from .TipFieldNormalization.application import FieldNormalizationApp
from .TipFileStorage.application import TipFileStorage
from .TipJobParseV2.application import TipJobParseV2
from .TipSpace import TipSpaceApp
from .TipTag import TipTagApp
from .TipTransmitter.application import TransmitterApp
from .ResumeSDK.application import ResumeSDKApplication
from .ChatGBT.application import ChatGBTApp
from .custom_session.custom_aiohttp_session import HoMuraSession


class TipMidApplication:

    def __init__(self, settings: Optional[dict]=None):
        self.session = HoMuraSession(
            aiohttp.ClientSession, retry_when=lambda x: not isinstance(x, asyncio.exceptions.TimeoutError)
        )
        settings = {} if not settings else settings
        settings_keys = list(settings.keys())
        if "EntityStorageServerHost" in settings_keys:
            self.source_entity_storage_app: SourceEntityStorageApp = SourceEntityStorageApp(self.session, settings)
        if "TipTagServerHost" in settings_keys:
            self.tip_tag_app: TipTagApp = TipTagApp(self.session, settings)
        if "ConvertServerHost" in settings_keys:
            self.convert_app: ConvertApp = ConvertApp(self.session, settings)
        if "TipSpaceServerHost" in settings_keys:
            self.tip_space_app: TipSpaceApp = TipSpaceApp(self.session, settings)
        if "TipTransmitterServerHost" in settings_keys:
            self.transmitter_app = TransmitterApp(self.session, settings)
        if "ResumeSDKServerHost" in settings_keys:
            self.resume_sdk_app = ResumeSDKApplication(self.session, settings)
        if "TipJobParseServerHost" in settings_keys:
            self.tip_job_parse_v2 = TipJobParseV2(self.session, settings)
        if "StoreDerivationServerHost" in settings_keys:
            self.tip_derivation_app = TipFileStorage(self.session, settings)
        self.chat_gbt_app = ChatGBTApp(self.session)
        self.field_normalization_app = FieldNormalizationApp()
