import aiohttp
import asyncio
from aiohttp.typedefs import StrOrURL
from typing import Type, Callable, Optional, Any, Coroutine
from loguru import logger
__all__ = ("HoMuraSession", )


class HoMuraSession:
    def __init__(
            self, client_session: Type[aiohttp.ClientSession], *, retry_time: int = 8,
            retry_interval: Optional[int] = 180, retry_when: Optional[Callable] = None,
            exception_class: Optional[Any] = None, exception_kwargs: Optional[dict] = None
    ):
        self.client_session = client_session
        self.retry_time = retry_time
        self.retry_interval = retry_interval
        self.retry_when = retry_when
        self.exception_class = exception_class
        self.exception_kwargs = exception_kwargs

    async def request(
        self, method: str, url: StrOrURL, /, **kwargs
    ):
        async with self.client_session() as session:
            last_error = Exception("")
            for i in range(self.retry_time):
                try:
                    res = await session.request(method.upper(), url, **kwargs)
                    break
                except Exception as _e:
                    if self.exception_class is None or self.exception_class is Exception:
                        last_error = _e
                    else:
                        last_error = self.exception_class(
                            "error message: {}".format(repr(_e)), **self.exception_kwargs or {}
                        )
                    if self.retry_when and not self.retry_when(_e):
                        raise last_error
                    logger.error("retry to request url: {}, method: {}, now request time: {}".format(
                        url, method, i + 1
                    ))
                    if self.retry_interval is not None:
                        await asyncio.sleep(self.retry_interval)
                    continue
            else:
                raise last_error

        return res

    async def get(self, url: StrOrURL, *, allow_redirects: bool = True, **kwargs):
        return await self.request('get', url, allow_redirects=allow_redirects, **kwargs)

    async def post(self, url: StrOrURL, *, data: Any = None, **kwargs):
        return await self.request('post', url, data=data, **kwargs)

    async def put(self, url: StrOrURL, *, data: Any = None, **kwargs):
        return await self.request('put', url, data=data, **kwargs)

    async def delete(self, url: StrOrURL, **kwargs):
        return await self.request('delete', url,  **kwargs)

    async def patch(self, url: StrOrURL,  **kwargs):
        return await self.request("patch", url, **kwargs)


